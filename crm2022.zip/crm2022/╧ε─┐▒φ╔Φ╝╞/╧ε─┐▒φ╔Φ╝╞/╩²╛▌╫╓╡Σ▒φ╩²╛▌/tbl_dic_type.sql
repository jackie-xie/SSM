﻿INSERT INTO `tbl_dic_type` VALUES 
('appellation','称呼',''),
('clueState','线索状态',''),
('returnPriority','回访优先级',''),
('returnState','回访状态',''),
('source','来源',''),
('stage','阶段',''),
('transactionType','交易类型','');