package com.powernode.service;

import com.powernode.pojo.User;
import com.baomidou.mybatisplus.extension.service.IService;

/**
* @author 93951
* @description 针对表【tbl_user】的数据库操作Service
* @createDate 2023-04-18 02:06:06
*/
public interface UserService extends IService<User> {

}
