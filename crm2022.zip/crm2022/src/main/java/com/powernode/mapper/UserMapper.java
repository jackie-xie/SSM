package com.powernode.mapper;

import com.powernode.pojo.User;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author 93951
* @description 针对表【tbl_user】的数据库操作Mapper
* @createDate 2023-04-18 02:06:06
* @Entity com.powernode.pojo.User
*/
public interface UserMapper extends BaseMapper<User> {

}




